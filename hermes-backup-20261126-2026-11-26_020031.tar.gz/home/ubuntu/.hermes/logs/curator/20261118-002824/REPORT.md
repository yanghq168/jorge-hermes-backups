# Curator run — 2026-11-18T00:28:24.278239+00:00

Model: `MiniMax-M3` via `custom`  ·  Duration: 1m 53s  ·  Agent-created skills: 3 → 3 (+0)

## Auto-transitions (pure, no LLM)

- checked: 3
- marked stale: 0
- archived (no LLM, pure time-based staleness): 0
- reactivated: 0

## LLM consolidation pass

- tool calls: **39** (by name: execute_code=20, skill_view=5, terminal=14)
- consolidated into umbrellas: **0**
- pruned (archived for staleness): **0**
- new skills this run: **0**
- state transitions (active ↔ stale ↔ archived): **0**

## LLM final summary

Clean. All three packages intact, no bytecode, all links verified.

## Curator pass summary

**Scope:** The candidate list contained only **3 agent-created skills**. The remaining ~100 skills in `~/.hermes/skills/` are bundled (`.bundled_manifest` = 84 hashes) or hub-installed (12 non-bundled skills with upstream `homepage:` fields — `notion`, `obsidian`, `summarize`, `weather`, `github`, etc.). Per hard rule #1, none were touched.

### Cluster analysis — why no archives

I scanned for prefix clusters (`hermes-*`, `gateway-*`, `codex-*`, `mcp-*`, `pr-*`, `*-audit`, `*-salvage`…) across the full tree. **The three candidates are the only agent-created skills, and all three are already in the target class-level shape:**

| Skill | Class it serves | Package | Verdict |
|---|---|---|---|
| `content-platforms` | Generate/distribute multi-platform content (WeChat/XHS/Toutiao/Douyin) | 111KB SKILL.md + 24 `references/` + 5 `scripts/` | Canonical umbrella |
| `cron-job-debugging` | Diagnose/recover silently-failing Hermes cron jobs | 105KB SKILL.md + 13 `references/` + 3 `scripts/` | Canonical umbrella |
| `openclaw-to-hermes-migration` | One-time OpenClaw→Hermes asset conversion | 15KB SKILL.md + 4 `references/` + 3 `templates/` | Canonical umbrella (distinct class) |

**Key finding — the collection has already been umbrella-ified.** The narrow, session-specific material (per-defect-family audits, per-month outage logs, probe scripts) is *already* demoted into `references/`/`scripts/`/`templates/`, not sitting as sibling top-level skills. The `content-platforms` reference bank contains exactly the kind of one-bug-per-file detail the prompt targets (`hook-promise-and-title-payoff-audit.md`, `golden-echo-and-label-provenance-audit.md`, `pool-wide-scan-and-linter-syntax-death.md`, …) — correctly filed under one discoverable umbrella.

**Key finding — the `content-platforms` ↔ `cron-job-debugging` boundary is clean, not duplicated.** `content-platforms` has 22 SMTP/outbox mentions, and every one is either a *pointer* ("诊断流程属于 `cron-job-debugging` 技能的职责，不要在这里重复推导") or a content-side fact. Zero shared reference files. Merging them would create a 216KB monolith spanning two genuinely different tasks (produce content vs. diagnose a scheduler) and destroy the delegation structure.

The one thing that *looked* like narrow-name sprawl — `toutiao-cron-outage-2026-08/-09/-10-week4.md` — is already inside `cron-job-debugging/references/`, is a deliberate chronological case series (Cases A–F → G–P → S+ → X/Y/Z) with `case-log-chronic-outage.md` as its index, and has 10+ inbound pointers. Folding it into one 145KB file would hurt navigation and break links.

**So: 0 archives.** All three are already class-level umbrellas and no proposed merge improves discoverability.

### Real defects found and fixed

Consolidation wasn't the only value available — package integrity had genuine breakage:

1. **30 broken cross-skill paths in `cron-job-debugging/SKILL.md`** — 28 of 30 used a bare `content-platforms/references/...` prefix that does not resolve from `cron-job-debugging`'s own directory (only 3 had the correct `productivity/` prefix). Rewrote all to the resolvable form. This directly violates the collection's own hard-won lesson: *"Never leave archived/demoted instructions pointing at files that were left behind under the old skill directory."*

2. **3 more broken links** — `toutiao-cron-outage-2026-10-week4.md` → `references/toutiao-article-daily.md` (lives in a sibling skill), and `qq-email-smtp-setup.md` → `scripts/probe_smtp.py` + `references/smtp-credential-failure-case-study.md` (live in `cron-job-debugging`). Fixed to resolvable sibling-prefixed paths.

3. **Stale bytecode** — 5 `.pyc` files under `content-platforms/scripts/__pycache__/`, including a `.cpython-312.pyc` alongside a `.cpython-311.pyc` of the same module (stale-interpreter hazard). Removed. This also enforces the migration skill's own pitfall #7.

**Verification:** 96 skill-style path references audited across 45 markdown files → 0 genuine broken links (7 remaining hits confirmed as quoted cron `script` *field values* like `cron/scripts/skill-backup.sh`, i.e. the path-resolution lesson's subject matter, not links). All 9 support scripts pass `py_compile`. All 3 skills re-verified loading via `skill_view` with full `references/`/`scripts/`/`templates/` discovery intact.

## Structured summary (required)
```yaml
consolidations: []
prunings: []
```

## Recovery

- Restore an archived skill: `hermes curator restore <name>`
- All archives live under `~/.hermes/skills/.archive/` and are recoverable by `mv`
- See `run.json` in this directory for the full machine-readable record.
